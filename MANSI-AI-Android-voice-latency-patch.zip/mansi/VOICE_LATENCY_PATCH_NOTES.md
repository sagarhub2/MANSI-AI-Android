# MANSI AI voice latency patch

Changes in this patch:
- Set the default Gemini Live voice to `Aoede` for a softer feminine voice on fresh installs.
- Bound the playback queue to 16 chunks and drop the oldest chunk when overloaded, avoiding stale speech backlog.
- Reduce AudioTrack buffering from a 2-second headroom target to a smaller low-latency buffer.
- Bound pre-connection microphone audio to about 400 ms, discarding oldest buffered chunks while the connection warms up.

Important:
- This is a source patch, not a verified APK.
- A full Android build could not be run in this environment because Gradle 8.9 must be downloaded from services.gradle.org and network access was unavailable.
- Actual end-to-end latency still depends on network quality, Gemini Live availability/model, device audio behavior, and runtime logs. Test on a device and tune if there are underruns or clipping.
